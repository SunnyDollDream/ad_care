<template>
  <div>MedicalRecord</div>
</template>

<script setup></script>

<style lang="less" scoped></style>
