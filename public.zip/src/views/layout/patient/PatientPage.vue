<template>
  <div class="main">
    <div class="left">
      <div class="header">
        <div class="title">问诊列表</div>
        <img src="@\assets\DoctorPage\doctor.svg" alt="" />
      </div>
      <div class="list">
        <!-- <div class="button">
          <div class="inner">
            <div class="left-cont">
              <div class="image"></div>
              <div class="left-text">测试</div>
            </div>
            <div class="right-text">测试</div>
          </div>
        </div> -->
        <div class="button">
          <ChatItem :icon="icon" @click="$router.push(`/patient/chat?id=${test}`)">测试</ChatItem>
        </div>
        <div class="button">
          <ChatItem :icon="icon" @click="chatSocket.sendMessage(msg)">测试</ChatItem>
        </div>
        <div class="button">
          <ChatItem :icon="icon">测试</ChatItem>
        </div>
        <div class="button">
          <ChatItem :icon="icon">测试</ChatItem>
        </div>
        <div class="button">
          <ChatItem :icon="icon">测试</ChatItem>
        </div>
        <div class="button">
          <ChatItem :icon="icon">测试</ChatItem>
        </div>
        <div class="button">
          <ChatItem :icon="icon">测试</ChatItem>
        </div>
      </div>
    </div>
    <div class="right">
      {{ chatSocket.message }}
    </div>
  </div>
</template>

<script setup>
import { ref, watch, onBeforeMount } from 'vue'
import ChatItem from '@/components/ChatItem.vue'
import { useUserStore, useWebSocketStore } from '@/stores'
import { chatGetHistoryPatientService } from '@/api/chat'

const userStore = useUserStore()
const webSocketStore = useWebSocketStore()

const chatSocket = webSocketStore.chatSocket
const users = ref([])
const chatHistory = ref([])

// onBeforeMount(async () => {
//   //获取历史患者
//   const {
//     data: { data },
//   } = await chatGetHistoryPatientService()
//   data.forEach((patient)=>{
//     users.forEach((user)=>{
//       if(patient.uid === user.uid) {
//         break
//       }
//       users.push({uid:patient.uid,})
//     })
//   })
//   users.value = data
//   console.log(users.value)
// })


watch(
  chatSocket,
  (newValue, oldValue) => {
    if (chatSocket.message === null) return
    // const test = JSON.stringify(newValue)
    // console.log(`接收到消息: ${chatSocket.message}`)
    if ('msgs' in chatSocket.message) {
      chatSocket.message.msgs.forEach(({ msg }) => {
        const { uid, from, icon } = JSON.parse(msg)
        const user = { uid, name: from, icon }
        if (!users.contain(user)) {
          users.push(user)
        }
      })
    } else {
    }
  },
  { deep: true },
)

const icon = ref(
  'http://101.126.153.13:9000/oss/b8a59b621b0442829859d4d3a362d708.jpg?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Credential=TBA9I7yHZN4apyxq9EJi%2F20250914%2Fus-east-1%2Fs3%2Faws4_request&X-Amz-Date=20250914T072053Z&X-Amz-Expires=604800&X-Amz-SignedHeaders=host&X-Amz-Signature=1911e8dcb2197e8619b2ec6b959d0618f82ed3b3c1dd2baf43a060c65affe51f',
)

const test = ref(1)

const msg = ref({ to: '9', msg: '我不好' })
</script>

<style lang="less" scoped>
// * {
//   border: 1px dashed grey;
//   box-sizing: border-box;
// }

.main {
  width: 100%;
  height: 100vh;
  display: flex;

  .left {
    width: 50%;
    height: 100%;
    display: flex;
    flex-direction: column;
    background-color: #dadff8;

    .header {
      width: 100%;
      height: 20%;
      display: flex;
      justify-content: space-evenly;
      box-sizing: border-box;
      padding: 3% 0;

      .title {
        display: flex;
        align-items: center;
        font-weight: bold;
        font-size: larger;
      }
    }

    .list {
      border-radius: 20px 20px 0 0;
      background-color: #fcfcfc;
      width: 100%;
      // height: 80%;
      flex: 1;

      overflow: auto;

      .button {
        width: 100%;
        height: 20%;
        display: flex;
        align-items: center;
        justify-content: center;

        .inner {
          width: 90%;
          height: 90%;
          border-radius: 20px;
          box-shadow: 0 0 2px;
          background-color: white;
          transition: all 0.3s;

          &:hover {
            filter: brightness(0.9);
          }

          &:active {
            filter: brightness(0.7);
          }

          display: flex;
          justify-content: space-around;
          align-items: center;

          .left-cont {
            width: 50%;
            height: 100%;
            display: flex;
            // justify-content: left;
            align-items: center;

            .image {
              height: 60%;
              aspect-ratio: 1/1;
              background-image: url('../../../assets/doctorpic/3.jpeg');
              background-size: contain;
              background-repeat: no-repeat;
              background-position: center;
              border-radius: 100%;
              margin-right: 10%;
            }
          }
        }
      }
    }
  }

  .right {
    width: 50%;
    height: 100%;
  }
}
</style>
