<template>
  <div>
    <!-- -->
  </div>
</template>

<script setup>
import useWebSocket from '@/utils/webSocketService.js'

const { isConnected, sendMessage, message } = useWebSocket('ws://101.126.153.13:8082/recovery/')

const handleMessage = (data) => {
  // 处理消息逻辑
  console.log('Handling message:', data)
}

</script>

<style lang="less" scoped></style>
