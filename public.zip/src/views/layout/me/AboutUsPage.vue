<template>
  <div style="display: flex; justify-content: center; align-items: center; height: 100%; width: 100%;">
    <el-descriptions title="关于我们" column="1" border="true" style="width: 80%;">
      <el-descriptions-item label="技术支持">SIPC</el-descriptions-item>
      <el-descriptions-item label="前端">xhy</el-descriptions-item>
      <el-descriptions-item label="后端">bpf</el-descriptions-item>
      <el-descriptions-item label="产品">szx</el-descriptions-item>
    </el-descriptions>
  </div>
</template>

<script setup>
import { ref } from 'vue'

const feature = ref()
</script>

<style lang="less" scoped></style>
