<template>
  <div>
    <el-container>
      <el-aside class="aside">
        <el-header class="header">
          <div class="logo"></div>
          <h3>银发智安</h3>
        </el-header>
        <el-menu
          active-text-color="#409EFF"
          background-color="#DBF4F3"
          default-active="/patient"
          class="el-menu-vertical-demo"
          @open="handleOpen"
          @close="handleClose"
          router="true"
          style="border: none"
        >
          <el-menu-item index="/patient">
            <el-icon><User /></el-icon>
            <template #title>患者</template>
          </el-menu-item>
          <el-menu-item index="/record">
            <el-icon><Document /></el-icon>
            <template #title>病历</template>
          </el-menu-item>
          <el-menu-item index="/ai">
            <el-icon><Opportunity /></el-icon>
            <template #title>AI辅助</template>
          </el-menu-item>
          <el-menu-item index="/me">
            <el-icon><House /></el-icon>
            <template #title>我的</template>
          </el-menu-item>
        </el-menu>
      </el-aside>
      <el-container>
        <RouterView></RouterView>
      </el-container>
    </el-container>
  </div>
</template>

<script setup>
import { useUserStore, useWebSocketStore } from '@/stores'
import useWebSocket from '@/utils/webSocketService'
import { User, Document, Opportunity, House } from '@element-plus/icons-vue'

const userStore = useUserStore()
const webSocketStore = useWebSocketStore()

const handleOpen = (key, keyPath) => {
  console.log(key, keyPath)
}
const handleClose = (key, keyPath) => {
  console.log(key, keyPath)
}

webSocketStore.setChatSocket(
  useWebSocket(`ws://101.126.153.13:8082/recovery/?Authorization=${userStore.token}`),
)
</script>

<style lang="less" scoped>
.aside {
  width: 15vw;
  height: 100vh;
  border-right: 2px solid #dcdfe6;
  border-radius: 10px;
  background-color: #dbf4f3;
  .header {
    padding: 0;
    width: 100%;
    display: flex;
    // height: 8vh;
    // justify-content: center;
    align-items: center;
    h3 {
      margin: 0 10px;
    }
  }
}
.logo {
  width: 50px;
  height: 50px;
  margin: 10px;
  border-radius: 100px;
  background-image: url('@/assets/login/logo.png');
  background-size: 150%;
  background-position: center 20%;
}
.ain {
  transition: all;
}
</style>
