import { defineComponent } from 'vue'
import useWebSocket from '@/utils/webSocketService' // 根据实际情况调整路径

export default defineComponent({
  setup() {
    const { isConnected, sendMessage, message } = useWebSocket(
      'ws://101.126.153.13:8082/recovery/',
    )

    const handleMessage = (data) => {
      // 处理消息逻辑
      console.log('Handling message:', data)
    }

    // 在这里你可以监听消息，或者发送消息
    return {
      isConnected,
      sendMessage,
      message,
      handleMessage,
    }
  },
})
