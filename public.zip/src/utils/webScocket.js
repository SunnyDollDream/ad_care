export const startConnect = (url) => {
  const ws = new WebSocket(url)

  ws.onclose = () => {
    console.log('ws断开')
  }

  ws.onerror = (error) => {
    console.log(error)
  }

  ws.onmessage = (event) => {
    console.log(`ws收到消息: ${event.data}`)
  }

  ws.onopen = () => {
    console.log('ws链接成功')
  }

  return ws
}
